
Partial Class Personal
    Inherits System.Web.UI.Page

End Class
