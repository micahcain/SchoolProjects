﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Type-It")> 
<Assembly: AssemblyDescription("A really not-so-impressive text editor made by a really not-so-imressive programmer. If you want to type simple text documents for use in other, much better word processors (and why wouldn't you?) then maybe Type-It is the program for you.")> 
<Assembly: AssemblyCompany("Micahsoft")> 
<Assembly: AssemblyProduct("Type-It")> 
<Assembly: AssemblyCopyright("Copyright © Micahsoft 2009")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("d1847ee2-628d-4564-aeb6-e85e272cf11d")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
