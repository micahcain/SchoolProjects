
Partial Class myResume
    Inherits System.Web.UI.Page

End Class
